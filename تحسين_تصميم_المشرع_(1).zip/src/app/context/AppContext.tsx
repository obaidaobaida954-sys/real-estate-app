import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { i18n, Language, Theme } from "../i18n";
import { Property, mockProperties } from "../data";
import { toast } from "sonner";

interface AppContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  t: (key: string) => string;
  favorites: Set<number>;
  toggleFavorite: (id: number) => void;
  properties: Property[];
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Language>("ar");
  const [theme, setTheme] = useState<Theme>("dark");
  const [favorites, setFavorites] = useState<Set<number>>(new Set());

  // Setup initial HTML attributes
  useEffect(() => {
    document.documentElement.setAttribute("dir", lang === "en" ? "ltr" : "rtl");
    document.documentElement.setAttribute("lang", lang);
  }, [lang]);

  useEffect(() => {
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [theme]);

  const t = (key: string) => {
    return (i18n[lang] as any)[key] || key;
  };

  const toggleFavorite = (id: number) => {
    setFavorites((prev) => {
      const newFavs = new Set(prev);
      if (newFavs.has(id)) {
        newFavs.delete(id);
        toast.success(t("fav_removed"), {
          style: {
            background: "var(--toast-bg)",
            color: "var(--toast-color)",
            borderColor: "var(--toast-border)",
          },
        });
      } else {
        newFavs.add(id);
        toast.success(t("fav_added"), {
          style: {
            background: "var(--toast-bg)",
            color: "var(--toast-color)",
            borderColor: "var(--toast-border)",
          },
        });
      }
      return newFavs;
    });
  };

  return (
    <AppContext.Provider
      value={{
        lang,
        setLang,
        theme,
        setTheme,
        t,
        favorites,
        toggleFavorite,
        properties: mockProperties,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useAppContext must be used within an AppProvider");
  }
  return context;
}
