import React from "react";
import { Info, ChevronLeft, Moon, Sun, Languages } from "lucide-react";
import { useAppContext } from "../context/AppContext";
import { toast } from "sonner";
import { motion } from "motion/react";
import { AnimatedPage } from "../components/AnimatedPage";

export function SettingsPage() {
  const { t, lang, setLang, theme, setTheme } = useAppContext();

  const handleLangToggle = (newLang: "ar" | "en") => {
    if (newLang !== lang) {
      setLang(newLang);
      toast.success(newLang === "ar" ? "تم تغيير اللغة إلى العربية" : "Language changed to English");
    }
  };

  const handleThemeToggle = (newTheme: "light" | "dark") => {
    if (newTheme !== theme) {
      setTheme(newTheme);
      toast.success(t(`theme_${newTheme}_on`));
    }
  };

  return (
    <AnimatedPage className="pt-2">
      <header className="glass sticky top-0 z-40 border-b border-border-subtle backdrop-blur-xl">
        <div className="flex items-center px-6 py-5">
          <h2 className="text-2xl font-extrabold text-text-main">
            {t("nav_settings")}
          </h2>
        </div>
      </header>

      <main className="flex-1 px-5 pt-8 overflow-y-auto w-full">
        {/* Language */}
        <section className="mb-10">
          <div className="flex items-center gap-2 mb-4 px-1">
            <Languages className="w-4 h-4 text-amber-500" />
            <h3 className="text-[11px] font-bold text-text-muted uppercase tracking-[0.2em]">
              {t("settings_language")}
            </h3>
          </div>
          <div className="flex gap-3 bg-surface-1 p-1.5 rounded-[20px] border border-border-subtle shadow-sm">
            <button
              onClick={() => handleLangToggle("ar")}
              className={`relative flex-1 py-3.5 rounded-[14px] text-sm font-bold transition-all ${
                lang === "ar" ? "text-stone-900" : "text-text-sub hover:text-text-main"
              }`}
            >
              {lang === "ar" && (
                <motion.div layoutId="lang-active" className="absolute inset-0 bg-gradient-to-r from-amber-400 to-amber-500 rounded-[14px] shadow-md" />
              )}
              <span className="relative z-10">العربية</span>
            </button>
            <button
              onClick={() => handleLangToggle("en")}
              className={`relative flex-1 py-3.5 rounded-[14px] text-sm font-bold transition-all ${
                lang === "en" ? "text-stone-900" : "text-text-sub hover:text-text-main"
              }`}
            >
              {lang === "en" && (
                <motion.div layoutId="lang-active" className="absolute inset-0 bg-gradient-to-r from-amber-400 to-amber-500 rounded-[14px] shadow-md" />
              )}
              <span className="relative z-10">English</span>
            </button>
          </div>
        </section>

        {/* Theme */}
        <section className="mb-10">
          <div className="flex items-center gap-2 mb-4 px-1">
            {theme === "dark" ? <Moon className="w-4 h-4 text-amber-500" /> : <Sun className="w-4 h-4 text-amber-500" />}
            <h3 className="text-[11px] font-bold text-text-muted uppercase tracking-[0.2em]">
              {t("settings_theme")}
            </h3>
          </div>
          <div className="flex gap-3 bg-surface-1 p-1.5 rounded-[20px] border border-border-subtle shadow-sm">
            <button
              onClick={() => handleThemeToggle("dark")}
              className={`relative flex-1 py-3.5 rounded-[14px] text-sm font-bold transition-all ${
                theme === "dark" ? "text-stone-900" : "text-text-sub hover:text-text-main"
              }`}
            >
              {theme === "dark" && (
                <motion.div layoutId="theme-active" className="absolute inset-0 bg-gradient-to-r from-amber-400 to-amber-500 rounded-[14px] shadow-md" />
              )}
              <span className="relative z-10">{t("theme_dark")}</span>
            </button>
            <button
              onClick={() => handleThemeToggle("light")}
              className={`relative flex-1 py-3.5 rounded-[14px] text-sm font-bold transition-all ${
                theme === "light" ? "text-stone-900" : "text-text-sub hover:text-text-main"
              }`}
            >
              {theme === "light" && (
                <motion.div layoutId="theme-active" className="absolute inset-0 bg-gradient-to-r from-amber-400 to-amber-500 rounded-[14px] shadow-md" />
              )}
              <span className="relative z-10">{t("theme_light")}</span>
            </button>
          </div>
        </section>

        {/* About */}
        <section className="mb-10">
          <div className="flex items-center gap-2 mb-4 px-1">
            <Info className="w-4 h-4 text-amber-500" />
            <h3 className="text-[11px] font-bold text-text-muted uppercase tracking-[0.2em]">
              {t("settings_about")}
            </h3>
          </div>
          <div className="flex flex-col gap-3">
            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              onClick={() => toast.info(lang === 'ar' ? 'تطبيق عقاري — منصة عقارات السويداء الأولى' : 'Aqari — The First Suwaida Real Estate Platform')}
              className="flex items-center justify-between w-full px-5 py-4 bg-surface-1 rounded-[20px] border border-border-subtle shadow-sm group"
            >
              <div className="flex items-center gap-4">
                <span className="font-bold text-text-main group-hover:text-amber-500 transition-colors">{t("about_info")}</span>
              </div>
              <div className="w-8 h-8 rounded-full bg-surface-2 flex items-center justify-center group-hover:bg-amber-500/10 transition-colors">
                <ChevronLeft className={`w-4 h-4 text-text-muted ${lang === 'en' ? 'rotate-180' : ''}`} />
              </div>
            </motion.button>

            <div className="flex items-center justify-between w-full px-5 py-4 bg-surface-1 rounded-[20px] border border-border-subtle shadow-sm">
              <span className="font-bold text-text-main">{t("about_version")}</span>
              <span className="text-text-muted text-sm font-mono tracking-widest bg-surface-2 px-3 py-1 rounded-lg">1.0.0</span>
            </div>
          </div>
        </section>

      </main>
    </AnimatedPage>
  );
}
