import React, { useState } from "react";
import { Shield, Plus, Bell, Phone, Mail, Send, Trash2, Edit, Check, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

// Simple password protection - في الإنتاج يجب استخدام authentication حقيقي
const ADMIN_PASSWORD = "admin2024";

export function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [activeTab, setActiveTab] = useState<"notifications" | "properties" | "contacts">("notifications");

  // Notification State
  const [notificationTitle, setNotificationTitle] = useState("");
  const [notificationMessage, setNotificationMessage] = useState("");

  // Contact State
  const [whatsapp, setWhatsapp] = useState("+963 XX XXX XXXX");
  const [phone, setPhone] = useState("+963 XX XXX XXXX");
  const [email, setEmail] = useState("info@aqari.sy");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      toast.success("تم تسجيل الدخول بنجاح");
    } else {
      toast.error("كلمة المرور غير صحيحة");
    }
  };

  const sendNotification = () => {
    if (!notificationTitle || !notificationMessage) {
      toast.error("يرجى ملء جميع الحقول");
      return;
    }

    // في الإنتاج: إرسال للـ backend ثم push notification
    toast.success("تم إرسال الإشعار لجميع المستخدمين");
    setNotificationTitle("");
    setNotificationMessage("");
  };

  const updateContacts = () => {
    // في الإنتاج: حفظ في قاعدة البيانات
    toast.success("تم تحديث معلومات التواصل");
  };

  // Login Screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-black p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <div className="text-center mb-8">
            <div className="w-20 h-20 mx-auto mb-6 rounded-[24px] bg-gradient-to-br from-red-500 to-red-700 flex items-center justify-center shadow-[0_10px_30px_-5px_rgba(239,68,68,0.4)]">
              <Shield className="w-10 h-10 text-white" strokeWidth={2} />
            </div>
            <h1 className="text-3xl font-extrabold text-white mb-2">لوحة التحكم</h1>
            <p className="text-gray-400 text-sm">مخصصة للمسؤولين فقط</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                كلمة المرور
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="أدخل كلمة المرور"
                className="w-full h-14 bg-surface-1 border border-border-subtle rounded-2xl px-4 text-text-main placeholder:text-text-muted focus:outline-none focus:border-red-500/50 focus:ring-4 focus:ring-red-500/10 transition-all"
              />
            </div>

            <button
              type="submit"
              className="w-full py-4 rounded-2xl font-bold text-base bg-gradient-to-r from-red-500 to-red-700 text-white hover:from-red-600 hover:to-red-800 transition-all shadow-lg"
            >
              تسجيل الدخول
            </button>
          </form>

          <p className="text-center text-gray-500 text-xs mt-6">
            كلمة المرور الافتراضية: admin2024
          </p>
        </motion.div>
      </div>
    );
  }

  // Admin Dashboard
  return (
    <div className="min-h-screen w-full bg-black pb-32">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-surface-1/95 backdrop-blur-xl border-b border-border-subtle">
        <div className="max-w-4xl mx-auto px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-500 to-red-700 flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" strokeWidth={2} />
            </div>
            <div>
              <h1 className="text-xl font-extrabold text-text-main">لوحة التحكم</h1>
              <p className="text-xs text-text-muted">مسؤول النظام</p>
            </div>
          </div>
          <button
            onClick={() => {
              setIsAuthenticated(false);
              setPassword("");
              toast.info("تم تسجيل الخروج");
            }}
            className="px-4 py-2 rounded-xl bg-surface-2 border border-border-subtle text-text-main text-sm font-medium hover:bg-red-500/10 hover:text-red-500 transition-colors"
          >
            تسجيل خروج
          </button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 pt-8">
        {/* Tabs */}
        <div className="flex gap-2 mb-8 bg-surface-1 p-1 rounded-2xl border border-border-subtle">
          {[
            { id: "notifications", label: "الإشعارات", icon: Bell },
            { id: "contacts", label: "معلومات التواصل", icon: Phone },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`relative flex-1 py-3 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2 ${
                  isActive ? "text-white" : "text-text-muted hover:text-text-main"
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="admin-tab-bg"
                    className="absolute inset-0 bg-gradient-to-r from-red-500 to-red-700 rounded-xl shadow-md"
                  />
                )}
                <tab.icon className="w-4 h-4 relative z-10" />
                <span className="relative z-10">{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content */}
        <AnimatePresence mode="wait">
          {activeTab === "notifications" && (
            <motion.div
              key="notifications"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <div className="bg-surface-1 rounded-2xl border border-border-subtle p-6">
                <div className="flex items-center gap-2 mb-6">
                  <Bell className="w-5 h-5 text-red-500" />
                  <h2 className="text-lg font-bold text-text-main">إرسال إشعار جديد</h2>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-text-main mb-2">
                      عنوان الإشعار
                    </label>
                    <input
                      type="text"
                      value={notificationTitle}
                      onChange={(e) => setNotificationTitle(e.target.value)}
                      placeholder="مثال: تحديث جديد"
                      className="w-full h-12 bg-surface-2 border border-border-subtle rounded-xl px-4 text-text-main placeholder:text-text-muted focus:outline-none focus:border-red-500/50 focus:ring-4 focus:ring-red-500/10 transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-text-main mb-2">
                      نص الإشعار
                    </label>
                    <textarea
                      value={notificationMessage}
                      onChange={(e) => setNotificationMessage(e.target.value)}
                      placeholder="مثال: تم إضافة ميزات جديدة للتطبيق"
                      rows={4}
                      className="w-full bg-surface-2 border border-border-subtle rounded-xl px-4 py-3 text-text-main placeholder:text-text-muted focus:outline-none focus:border-red-500/50 focus:ring-4 focus:ring-red-500/10 transition-all resize-none"
                    />
                  </div>

                  <button
                    onClick={sendNotification}
                    className="w-full py-4 rounded-xl font-bold text-base bg-gradient-to-r from-red-500 to-red-700 text-white hover:from-red-600 hover:to-red-800 transition-all shadow-lg flex items-center justify-center gap-2"
                  >
                    <Send className="w-5 h-5" />
                    إرسال للجميع
                  </button>
                </div>
              </div>

              <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-4">
                <p className="text-sm text-amber-500 leading-relaxed">
                  <strong>ملاحظة:</strong> سيتم إرسال الإشعار لجميع مستخدمي التطبيق فوراً. تأكد من صحة المعلومات قبل الإرسال.
                </p>
              </div>
            </motion.div>
          )}

          {activeTab === "contacts" && (
            <motion.div
              key="contacts"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <div className="bg-surface-1 rounded-2xl border border-border-subtle p-6">
                <div className="flex items-center gap-2 mb-6">
                  <Phone className="w-5 h-5 text-red-500" />
                  <h2 className="text-lg font-bold text-text-main">تحديث معلومات التواصل</h2>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-text-main mb-2 flex items-center gap-2">
                      <Send className="w-4 h-4 text-green-500" />
                      رقم الواتساب
                    </label>
                    <input
                      type="text"
                      value={whatsapp}
                      onChange={(e) => setWhatsapp(e.target.value)}
                      placeholder="+963 XX XXX XXXX"
                      className="w-full h-12 bg-surface-2 border border-border-subtle rounded-xl px-4 text-text-main placeholder:text-text-muted focus:outline-none focus:border-red-500/50 focus:ring-4 focus:ring-red-500/10 transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-text-main mb-2 flex items-center gap-2">
                      <Phone className="w-4 h-4 text-blue-500" />
                      رقم الهاتف
                    </label>
                    <input
                      type="text"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+963 XX XXX XXXX"
                      className="w-full h-12 bg-surface-2 border border-border-subtle rounded-xl px-4 text-text-main placeholder:text-text-muted focus:outline-none focus:border-red-500/50 focus:ring-4 focus:ring-red-500/10 transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-text-main mb-2 flex items-center gap-2">
                      <Mail className="w-4 h-4 text-purple-500" />
                      البريد الإلكتروني
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="info@aqari.sy"
                      className="w-full h-12 bg-surface-2 border border-border-subtle rounded-xl px-4 text-text-main placeholder:text-text-muted focus:outline-none focus:border-red-500/50 focus:ring-4 focus:ring-red-500/10 transition-all"
                    />
                  </div>

                  <button
                    onClick={updateContacts}
                    className="w-full py-4 rounded-xl font-bold text-base bg-gradient-to-r from-red-500 to-red-700 text-white hover:from-red-600 hover:to-red-800 transition-all shadow-lg flex items-center justify-center gap-2"
                  >
                    <Check className="w-5 h-5" />
                    حفظ التغييرات
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
