import React, { useState, useMemo } from "react";
import { Search, Map, Home, Building2, Store, TreePine, ChevronDown, ChevronUp } from "lucide-react";
import { useAppContext } from "../context/AppContext";
import { PropertyCard } from "../components/PropertyCard";
import { PropertyModal } from "../components/PropertyModal";
import { AnimatedPage } from "../components/AnimatedPage";
import { NotificationBell } from "../components/NotificationBell";
import { Property } from "../data";
import { motion, AnimatePresence } from "motion/react";

type SortType = "price" | "area" | "date" | null;
type SortDir = "asc" | "desc";

export function HomePage() {
  const { t, properties } = useAppContext();
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | "sale" | "rent">("all");
  const [catFilter, setCatFilter] = useState<"all" | "house" | "apartment" | "commercial" | "land">("all");
  const [sortMenuOpen, setSortMenuOpen] = useState(false);
  const [sortType, setSortType] = useState<SortType>(null);
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);

  const categories = [
    { id: "all", icon: Map, label: "cat_all" },
    { id: "house", icon: Home, label: "cat_houses" },
    { id: "apartment", icon: Building2, label: "cat_apartments" },
    { id: "commercial", icon: Store, label: "cat_commercial" },
    { id: "land", icon: TreePine, label: "cat_land" },
  ];

  const filteredProperties = useMemo(() => {
    let list = properties.filter((p) => {
      const matchSearch =
        search === "" ||
        t(`prop${p.id}_title`).toLowerCase().includes(search.toLowerCase());
      const matchType = typeFilter === "all" || p.type === typeFilter;
      const matchCat = catFilter === "all" || p.category === catFilter;
      return matchSearch && matchType && matchCat;
    });

    if (sortType) {
      list.sort((a, b) => {
        let valA = 0;
        let valB = 0;
        if (sortType === "price") {
          valA = a.priceNum;
          valB = b.priceNum;
        } else if (sortType === "area") {
          valA = a.area;
          valB = b.area;
        } else if (sortType === "date") {
          valA = new Date(a.dateAdded).getTime();
          valB = new Date(b.dateAdded).getTime();
        }
        if (sortDir === "asc") return valA - valB;
        return valB - valA;
      });
    }

    return list;
  }, [properties, search, typeFilter, catFilter, sortType, sortDir, t]);

  const handleSort = (type: SortType) => {
    if (sortType === type) {
      setSortDir((prev) => (prev === "asc" ? "desc" : "asc"));
    } else {
      setSortType(type);
      setSortDir(type === "price" ? "asc" : "desc");
    }
    setSortMenuOpen(false);
  };

  const getDynamicTitle = () => {
    if (typeFilter === "all" && catFilter === "all") return t("title_all_properties");
    if (typeFilter !== "all" && catFilter === "all") return typeFilter === "sale" ? t("title_sale") : t("title_rent");
    return t(`title_cat_${catFilter}`);
  };

  return (
    <AnimatedPage className="pt-2">
      {/* Hero Header Greeting with Notification */}
      <div className="px-5 pt-8 pb-4">
        <div className="flex items-start justify-between mb-2">
          <div className="flex-1">
            <motion.h1
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
              className="text-3xl font-extrabold text-text-main leading-snug mb-1"
            >
              أهلاً بك في <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600">عقاري</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
              className="text-text-muted text-sm"
            >
              اكتشف العقار المثالي لك
            </motion.p>
          </div>
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
          >
            <NotificationBell />
          </motion.div>
        </div>
      </div>

      <main className="flex-1 px-5 pt-4 overflow-y-auto w-full">
        {/* Search */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="relative mb-6"
        >
          <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-text-muted" />
          </div>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("search_placeholder")}
            className="w-full h-14 bg-surface-1/50 backdrop-blur-xl border border-border-subtle rounded-[20px] pr-12 pl-4 text-text-main placeholder:text-text-muted focus:outline-none focus:border-amber-500/50 focus:ring-4 focus:ring-amber-500/10 transition-all shadow-sm"
          />
        </motion.div>

        {/* Type Filters */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
          className="flex gap-2 mb-8 bg-surface-1 p-1 rounded-2xl border border-border-subtle shadow-sm"
        >
          {["all", "sale", "rent"].map((type) => {
            const isActive = typeFilter === type;
            return (
              <button
                key={type}
                onClick={() => setTypeFilter(type as any)}
                className={`relative flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                  isActive ? "text-stone-900" : "text-text-muted hover:text-text-main"
                }`}
              >
                {isActive && (
                  <motion.div 
                    layoutId="type-bg" 
                    className="absolute inset-0 bg-gradient-to-r from-amber-400 to-amber-500 rounded-xl shadow-md"
                  />
                )}
                <span className="relative z-10">{t(`filter_${type}`)}</span>
              </button>
            );
          })}
        </motion.div>

        {/* Category Filters */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
          className="flex gap-4 mb-8 overflow-x-auto pb-2 scrollbar-hide snap-x"
        >
          {categories.map((cat) => {
            const isActive = catFilter === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setCatFilter(cat.id as any)}
                className="flex flex-col items-center gap-2.5 min-w-[72px] snap-center group"
              >
                <div
                  className={`w-[60px] h-[60px] rounded-[20px] flex items-center justify-center transition-all duration-300 ${
                    isActive
                      ? "bg-gradient-to-br from-amber-400 to-amber-600 text-stone-900 shadow-[0_8px_20px_-6px_rgba(245,158,11,0.5)] transform -translate-y-1"
                      : "bg-surface-1 border border-border-subtle text-text-muted group-hover:bg-surface-2 group-hover:text-text-main shadow-sm"
                  }`}
                >
                  <cat.icon className="w-[26px] h-[26px]" strokeWidth={isActive ? 2 : 1.5} />
                </div>
                <span className={`text-[11px] ${isActive ? "text-amber-500 font-bold" : "text-text-muted font-medium group-hover:text-text-main"}`}>
                  {t(cat.label)}
                </span>
              </button>
            );
          })}
        </motion.div>

        {/* Header & Sort */}
        <motion.div 
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }}
          className="flex items-center justify-between mb-5"
        >
          <h3 className="text-xl font-bold text-text-main">
            {getDynamicTitle()}
          </h3>

          <div className="relative">
            <button
              onClick={() => setSortMenuOpen(!sortMenuOpen)}
              className="flex items-center gap-1.5 text-sm text-text-sub hover:text-text-main transition-colors bg-surface-1 border border-border-subtle shadow-sm px-3 py-1.5 rounded-xl"
            >
              <span className="text-[12px] font-medium">{t("sort_by")}</span>
              {sortMenuOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            <AnimatePresence>
              {sortMenuOpen && (
                <motion.div
                  initial={{ opacity: 0, y: -10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -10, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  className="absolute top-full mt-2 left-0 w-56 bg-surface-1/95 backdrop-blur-xl border border-border-subtle rounded-2xl shadow-2xl overflow-hidden z-30"
                >
                  {["price", "area", "date"].map((type) => (
                    <button
                      key={type}
                      onClick={() => handleSort(type as SortType)}
                      className={`w-full text-right px-4 py-3 text-sm transition-colors flex justify-between items-center border-b border-border-subtle/30 last:border-0 ${
                        sortType === type ? "bg-amber-500/10 text-amber-500" : "text-text-main hover:bg-surface-2"
                      }`}
                    >
                      <span className="font-medium">{t(`sort_${type}`)}</span>
                      <div className="flex items-center gap-2">
                        {sortType === type && (
                          <span className="text-xs px-2 py-0.5 bg-amber-500/20 rounded-md">
                            {sortDir === "asc" ? "تصاعدي ↑" : "تنازلي ↓"}
                          </span>
                        )}
                      </div>
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>

        {/* Properties Grid */}
        <div className="flex flex-col gap-6">
          <AnimatePresence mode="popLayout">
            {filteredProperties.length > 0 ? (
              filteredProperties.map((p, index) => (
                <motion.div
                  key={p.id}
                  layout
                  initial={{ opacity: 0, y: 20, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                >
                  <PropertyCard property={p} onClick={() => setSelectedProperty(p)} />
                </motion.div>
              ))
            ) : (
              <motion.div 
                initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                className="py-20 text-center text-text-muted"
              >
                <p>{t("saved_empty")}</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      <PropertyModal
        property={selectedProperty}
        isOpen={!!selectedProperty}
        onClose={() => setSelectedProperty(null)}
      />
    </AnimatedPage>
  );
}
