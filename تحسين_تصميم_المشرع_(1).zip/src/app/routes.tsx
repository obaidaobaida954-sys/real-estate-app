import React from "react";
import { createBrowserRouter, Navigate } from "react-router";
import { Layout } from "./Layout";
import { Splash } from "./pages/Splash";
import { HomePage } from "./pages/Home";
import { SavedPage } from "./pages/Saved";
import { ContactPage } from "./pages/Contact";
import { SettingsPage } from "./pages/Settings";
import { AdminPage } from "./pages/Admin";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Splash,
  },
  {
    path: "/admin",
    Component: AdminPage,
  },
  {
    path: "/",
    Component: Layout,
    children: [
      { path: "home", Component: HomePage },
      { path: "saved", Component: SavedPage },
      { path: "contact", Component: ContactPage },
      { path: "settings", Component: SettingsPage },
    ],
  },
  {
    path: "*",
    element: <Navigate to="/" replace />,
  },
]);
