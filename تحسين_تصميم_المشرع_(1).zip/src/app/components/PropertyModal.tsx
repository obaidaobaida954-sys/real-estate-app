import React, { useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Heart, MapPin, X, BedDouble, Bath, Maximize, Phone, MessageCircle } from "lucide-react";
import { Property } from "../data";
import { useAppContext } from "../context/AppContext";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface PropertyModalProps {
  property: Property | null;
  isOpen: boolean;
  onClose: () => void;
}

export function PropertyModal({ property, isOpen, onClose }: PropertyModalProps) {
  const { t, lang, favorites, toggleFavorite } = useAppContext();

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    if (isOpen) document.addEventListener("keydown", handleEsc);
    return () => document.removeEventListener("keydown", handleEsc);
  }, [isOpen, onClose]);

  if (!property) return null;

  const isFav = favorites.has(property.id);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-md"
            onClick={onClose}
          />
          <motion.div
            initial={{ y: "100%", opacity: 0.5 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: "100%", opacity: 0 }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed inset-x-0 bottom-0 z-[70] w-full max-w-md mx-auto bg-surface-0 rounded-t-[32px] overflow-hidden max-h-[92vh] flex flex-col shadow-2xl"
          >
            {/* Top Indicator */}
            <div className="absolute top-3 left-1/2 -translate-x-1/2 w-12 h-1.5 rounded-full bg-white/30 z-20" />
            
            <div className="overflow-y-auto overflow-x-hidden flex-1 pb-28">
              {/* Hero Image */}
              <div className="relative h-80 w-full bg-black">
                <ImageWithFallback
                  src={property.img}
                  alt={t(`prop${property.id}_title`)}
                  className="w-full h-full object-cover opacity-90"
                />
                
                <div className="absolute inset-0 bg-gradient-to-t from-surface-0 via-transparent to-black/30 pointer-events-none" />

                {/* Close Button Floating */}
                <button
                  className="absolute top-5 right-5 w-10 h-10 rounded-full bg-black/30 backdrop-blur-xl border border-white/10 flex items-center justify-center z-20 transition-transform hover:scale-110 active:scale-90 text-white hover:text-amber-500"
                  onClick={onClose}
                >
                  <X className="w-5 h-5" />
                </button>

                {/* Favorite Button Floating */}
                <button
                  className="absolute top-5 left-5 w-10 h-10 rounded-full bg-black/30 backdrop-blur-xl border border-white/10 flex items-center justify-center z-20 transition-transform hover:scale-110 active:scale-90"
                  onClick={() => toggleFavorite(property.id)}
                >
                  <Heart
                    className={`w-5 h-5 transition-colors duration-300 ${
                      isFav ? "fill-red-500 text-red-500" : "text-white hover:text-red-400"
                    }`}
                  />
                </button>

                {property.badge && (
                  <div className="absolute bottom-6 right-6 z-10">
                    <span className={`text-[10px] font-bold px-3 py-1.5 rounded-xl backdrop-blur-md shadow-lg ${property.badgeColor}`}>
                      {t(property.badge)}
                    </span>
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="px-6 pt-4">
                <div className="flex items-start justify-between mb-4 gap-3">
                  <h2 className="text-2xl font-extrabold text-text-main leading-tight">
                    {t(`prop${property.id}_title`)}
                  </h2>
                </div>

                <div className="flex items-center gap-2 mb-8">
                  <span className="text-2xl font-bold text-amber-500 whitespace-nowrap">
                    {property.price} <span className="text-base">{t("currency")}</span>
                  </span>
                  {property.priceNote && (
                    <span className="text-sm font-medium text-text-muted bg-surface-1 px-2 py-1 rounded-lg">
                      {t(property.priceNote)}
                    </span>
                  )}
                </div>

                <p className="text-text-muted text-sm mb-8 flex items-center gap-2 bg-surface-1 p-3 rounded-xl border border-border-subtle">
                  <MapPin className="w-5 h-5 text-amber-500 shrink-0" />
                  {lang === 'ar' ? property.location.ar : property.location.en}
                </p>

                {/* Specs */}
                <div className="flex gap-3 mb-8">
                  {property.rooms > 0 && (
                    <div className="flex-1 bg-surface-1 rounded-2xl p-4 flex flex-col items-center justify-center border border-border-subtle">
                      <BedDouble className="w-6 h-6 text-amber-500 mb-2 opacity-80" />
                      <p className="text-xl font-bold text-text-main">{property.rooms}</p>
                      <p className="text-[11px] text-text-muted mt-1 font-medium">{t("rooms")}</p>
                    </div>
                  )}
                  {property.baths > 0 && (
                    <div className="flex-1 bg-surface-1 rounded-2xl p-4 flex flex-col items-center justify-center border border-border-subtle">
                      <Bath className="w-6 h-6 text-amber-500 mb-2 opacity-80" />
                      <p className="text-xl font-bold text-text-main">{property.baths}</p>
                      <p className="text-[11px] text-text-muted mt-1 font-medium">{property.baths > 1 ? t("baths") : t("bath")}</p>
                    </div>
                  )}
                  <div className="flex-1 bg-surface-1 rounded-2xl p-4 flex flex-col items-center justify-center border border-border-subtle">
                    <Maximize className="w-6 h-6 text-amber-500 mb-2 opacity-80" />
                    <p className="text-xl font-bold text-text-main">{property.area}</p>
                    <p className="text-[11px] text-text-muted mt-1 font-medium">{t("sqm")}</p>
                  </div>
                </div>

                {/* Description */}
                <h3 className="text-lg font-bold text-text-main mb-3">{t("title_cat_all")}</h3>
                <p className="text-text-sub text-[15px] leading-relaxed mb-8">
                  {t(`prop${property.id}_desc`)}
                </p>

                {/* Agent Card */}
                <div className="bg-gradient-to-br from-surface-1 to-surface-2 rounded-2xl p-5 mb-6 border border-border-subtle relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl" />
                  <p className="text-[10px] text-text-muted mb-2 uppercase tracking-[0.2em] font-bold">
                    {t("estate_office")}
                  </p>
                  <p className="text-text-main font-bold text-lg mb-1 relative z-10">
                    {lang === 'ar' ? property.agent.ar : property.agent.en}
                  </p>
                  <p className="text-amber-500 text-sm font-mono tracking-wider relative z-10" dir="ltr">
                    {property.phone}
                  </p>
                </div>
              </div>
            </div>

            {/* Sticky Action Bar */}
            <div className="absolute bottom-0 inset-x-0 bg-surface-0/90 backdrop-blur-xl border-t border-border-subtle p-4 px-6 flex gap-3 z-30 shadow-[0_-10px_40px_rgba(0,0,0,0.2)]">
               <button className="flex-1 btn-premium py-4 rounded-[18px] font-bold text-base flex items-center justify-center gap-2">
                 <Phone className="w-5 h-5" />
                 اتصال
               </button>
               <button className="w-14 h-14 shrink-0 bg-emerald-500 text-white rounded-[18px] flex items-center justify-center shadow-lg shadow-emerald-500/20 hover:scale-105 active:scale-95 transition-all">
                 <MessageCircle className="w-6 h-6" />
               </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
