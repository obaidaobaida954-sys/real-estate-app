import React from "react";
import { Heart, Maximize, BedDouble, Bath } from "lucide-react";
import { Property } from "../data";
import { useAppContext } from "../context/AppContext";
import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface PropertyCardProps {
  property: Property;
  onClick: () => void;
}

export function PropertyCard({ property, onClick }: PropertyCardProps) {
  const { t, favorites, toggleFavorite } = useAppContext();
  const isFav = favorites.has(property.id);

  return (
    <motion.div
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
      className="relative rounded-[24px] overflow-hidden bg-surface-0 border border-border-subtle cursor-pointer shadow-lg hover:shadow-2xl transition-all duration-300 group"
      onClick={onClick}
    >
      {/* Image Container */}
      <div className="relative h-[220px] w-full overflow-hidden p-2 pb-0">
        <div className="relative w-full h-full rounded-[18px] overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent z-10 pointer-events-none" />
          <ImageWithFallback
            src={property.img}
            alt={t(`prop${property.id}_title`)}
            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
          />

          {/* Badge */}
          {property.badge && (
            <div className="absolute top-3 right-3 z-20">
              <span className={`text-[10px] font-bold px-3 py-1.5 rounded-xl backdrop-blur-md shadow-lg ${property.badgeColor}`}>
                {t(property.badge)}
              </span>
            </div>
          )}

          {/* Favorite Button */}
          <button
            className={`absolute top-3 left-3 w-10 h-10 rounded-full bg-black/30 backdrop-blur-xl border border-white/10 flex items-center justify-center z-20 transition-transform hover:scale-110 active:scale-90`}
            onClick={(e) => {
              e.stopPropagation();
              toggleFavorite(property.id);
            }}
          >
            <Heart
              className={`w-[18px] h-[18px] transition-colors duration-300 ${
                isFav ? "fill-red-500 text-red-500 drop-shadow-[0_0_8px_rgba(239,68,68,0.5)]" : "text-white"
              }`}
            />
          </button>

          {/* Price inside Image */}
          <div className="absolute bottom-3 right-4 z-20">
            <p className="text-2xl font-bold text-white drop-shadow-xl flex items-baseline gap-1">
              {property.price}{" "}
              <span className="text-xs font-medium text-white/80">{t("currency")}</span>
              {property.priceNote && (
                <span className="text-[10px] font-normal text-white/60 ml-1">{t(property.priceNote)}</span>
              )}
            </p>
          </div>
        </div>
      </div>

      {/* Info Container */}
      <div className="px-5 py-4">
        <h4 className="font-bold text-text-main text-[16px] mb-3 truncate group-hover:text-amber-500 transition-colors">
          {t(`prop${property.id}_title`)}
        </h4>

        {/* Clean Spec Line (no heavy chips) */}
        <div className="flex items-center gap-3 text-text-muted text-xs font-medium overflow-hidden">
          {property.rooms > 0 && (
            <div className="flex items-center gap-1.5 whitespace-nowrap">
              <BedDouble className="w-4 h-4 text-amber-500" />
              <span>{property.rooms} {t("rooms")}</span>
            </div>
          )}
          
          {property.rooms > 0 && property.baths > 0 && <span className="w-1 h-1 rounded-full bg-border-subtle" />}
          
          {property.baths > 0 && (
            <div className="flex items-center gap-1.5 whitespace-nowrap">
              <Bath className="w-4 h-4 text-amber-500" />
              <span>{property.baths} {property.baths > 1 ? t("baths") : t("bath")}</span>
            </div>
          )}
          
          {(property.rooms > 0 || property.baths > 0) && <span className="w-1 h-1 rounded-full bg-border-subtle" />}
          
          <div className="flex items-center gap-1.5 whitespace-nowrap">
            <Maximize className="w-4 h-4 text-amber-500" />
            <span>{property.area} {t("sqm")}</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
