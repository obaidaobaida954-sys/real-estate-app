import React, { useState } from "react";
import { Bell, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useAppContext } from "../context/AppContext";

// Mock notifications - في المستقبل ستأتي من Dashboard Admin
const mockNotifications = [
  {
    id: 1,
    title: "تحديث جديد",
    message: "تم إضافة ميزات جديدة للتطبيق",
    time: "منذ ساعة",
    read: false
  },
  {
    id: 2,
    title: "عقارات جديدة",
    message: "تم إضافة 5 عقارات جديدة في السويداء",
    time: "منذ ساعتين",
    read: false
  },
];

export function NotificationBell() {
  const { lang } = useAppContext();
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState(mockNotifications);

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = (id: number) => {
    setNotifications(prev =>
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  return (
    <div className="relative">
      {/* Bell Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative w-10 h-10 rounded-full bg-surface-1 border border-border-subtle flex items-center justify-center hover:bg-surface-2 transition-all"
      >
        <Bell className="w-5 h-5 text-text-main" strokeWidth={2} />
        {unreadCount > 0 && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-white text-[10px] font-bold border-2 border-black"
          >
            {unreadCount}
          </motion.div>
        )}
      </button>

      {/* Notifications Panel */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40"
            />

            {/* Panel */}
            <motion.div
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              className={`absolute top-12 ${lang === 'ar' ? 'right-0' : 'left-0'} w-80 max-h-96 bg-surface-1/95 backdrop-blur-xl border border-border-subtle rounded-2xl shadow-2xl overflow-hidden z-50`}
            >
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-border-subtle">
                <h3 className="text-text-main font-bold">الإشعارات</h3>
                <div className="flex items-center gap-2">
                  {unreadCount > 0 && (
                    <button
                      onClick={markAllAsRead}
                      className="text-xs text-amber-500 hover:text-amber-400 font-medium"
                    >
                      تعليم الكل كمقروء
                    </button>
                  )}
                  <button
                    onClick={() => setIsOpen(false)}
                    className="w-6 h-6 rounded-full hover:bg-surface-2 flex items-center justify-center"
                  >
                    <X className="w-4 h-4 text-text-muted" />
                  </button>
                </div>
              </div>

              {/* Notifications List */}
              <div className="max-h-80 overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="p-8 text-center text-text-muted text-sm">
                    لا توجد إشعارات
                  </div>
                ) : (
                  notifications.map(notification => (
                    <motion.div
                      key={notification.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      onClick={() => markAsRead(notification.id)}
                      className={`p-4 border-b border-border-subtle/30 cursor-pointer transition-colors ${
                        !notification.read ? "bg-amber-500/5 hover:bg-amber-500/10" : "hover:bg-surface-2"
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        {!notification.read && (
                          <div className="w-2 h-2 mt-1.5 rounded-full bg-amber-500 flex-shrink-0" />
                        )}
                        <div className="flex-1">
                          <h4 className={`text-sm font-bold mb-1 ${!notification.read ? "text-text-main" : "text-text-sub"}`}>
                            {notification.title}
                          </h4>
                          <p className="text-xs text-text-muted leading-relaxed mb-1">
                            {notification.message}
                          </p>
                          <span className="text-[10px] text-text-muted/70">
                            {notification.time}
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
